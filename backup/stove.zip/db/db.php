<?php
// Connecting to the Database
   
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "cakezone";

    $conn = mysqli_connect($servername, $username, $password, $database);

?>